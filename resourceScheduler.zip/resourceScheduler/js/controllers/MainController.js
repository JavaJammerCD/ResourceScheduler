angular.module('resourceApp').controller('MainController', function ($scope, $http) {
    $scope.title = "Resource Scheduler";

    var users = [["Charlie", "Draper", "1"],
                 ["Elliot",  "Jenkins","2"],
                 ["Dayam",   "Javed",  "3"],
                 ["Miguel",  "Antunes","4"]];

    var randomNumber = Math.floor(Math.random() * 4);

    $scope.firstname = users[randomNumber][0];
    $scope.surname = users[randomNumber][1];
    $scope.employeeID = users[randomNumber][2];

    calanderObj = new JsDatePick({
        useMode: 1,
        isStripped: true,
        target: "calander"
    });
    calanderObj.setOnSelectedDelegate(function () {
        var obj = calanderObj.getSelectedDay();
        //alert("a date was just selected and the date is : " + obj.day + "/" + obj.month + "/" + obj.year);
        $scope.bookingDate = obj.year + "-" + obj.month + "-" + obj.day;
    });


    $scope.startTime = $('#start-time').clockpicker({
        placement: 'top',
        align: 'left',
        autoclose: true,
        'default': '09:00'
    });


    $scope.endTime = $('#end-time').clockpicker({
        placement: 'top',
        align: 'left',
        autoclose: true,
        'default': '17:30'
    });


    $scope.createBooking = function () {
        var jsonObj = {

            "date": $scope.bookingDate,
            "start_time": $scope.startTime.val().replace(":", "."),
            "end_time": $scope.endTime.val().replace(":", "."),
            "id": $scope.deskID,
            "resourceName": $scope.deskName,
            "employeeID": 1
        }

        var jsonString = JSON.stringify(jsonObj);
        console.log(jsonString);


        var req = {
            data: jsonString,
            method: 'POST',
            url: "http://localhost:8080/reservations/",
            headers: {
                'Authorization': "Access-Control-Allow-Origin"
            }
        }
        return $http(req).then(function (resp) {
            console.log(req);
            console.log(resp);
        }).catch(function (err) {
            return err;
        });
    }


    var acc = document.getElementsByClassName("accordion");
    var i;

    for (i = 0; i < acc.length; i++) {
        acc[i].onclick = function () {
			/* Toggle between adding and removing the "active" class,
			to highlight the button that controls the panel */
            this.classList.toggle("active");

            /* Toggle between hiding and showing the active panel */
            var panel = this.nextElementSibling;
            if (panel.style.display === "block") {
                panel.style.display = "none";
            } else {
                panel.style.display = "block";
            }
        }
    }
    var image = new ol.style.Circle({
        radius: 5,
        fill: null,
        stroke: new ol.style.Stroke({ color: 'red', width: 1 })
    });

    var styleFunction = function (feature) {
        var properties = feature.getProperties();
        var type = feature.getGeometry().getType();
        if (type === 'Circle') {
            return new ol.style.Style({
                stroke: new ol.style.Stroke({
                    color: 'red',
                    width: 2
                }),
                fill: new ol.style.Fill({
                    color: 'rgba(255,0,0,0.2)'
                })
            })
        } else {
            var colour = 'green';
            var desk = false;
            if (properties.deskName === 'Layout_Desk') {
                colour = 'rgba(9,20,147,0.2)'
            } else if (properties.deskName === 'Layout') {
                colour = 'rgba(40,160,228,0.8)'
            } else {
                desk = true;
                var IDpos = properties.deskName.indexOf('C') + 1;
                var deskID = properties.deskName.substring(IDpos);
                properties.status = checkDeskStatus(deskID);
                if (properties.status === 'Booked') {
                    colour = 'red';
                }
            }
            return new ol.style.Style({
                stroke: new ol.style.Stroke({
                    color: colour,
                    width: 3
                }),
                fill: new ol.style.Fill({
                    color: colour
                }),
                text: new ol.style.Text({
                    font: '10px Arial,sans-serif',
                    fill: new ol.style.Fill({ color: '#000' }),
                    text: desk ? properties.deskName : ""
                })
            })
        }
    };

    var geojsonObject = {
        'type': 'FeatureCollection',
        'crs': {
            'type': 'name',
            'properties': {
                'name': 'EPSG:3857'
            }
        },
        'features': [
            {
                'type': 'Feature',
                'properties': {
                    'deskName': 'Layout'
                },
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[-62e6, -15e6], [-63e6, -15e6], [-63e6, -10e6], [-62e6, -10e6], [-62e6, -6e6], [-63e6, -6e6], [-63e6, -1e6], [-62e6, -1e6], [-62e6, 1e6], [-38e6, 1e6], [-38e6, -10e6], [-33e6, -10e6], [-33e6, 1e6], [-3e6, 1e6], [-3e6, -1e6], [-2e6, -1e6], [-2e6, -6e6], [-3e6, -6e6], [-3e6, -10e6], [-2e6, -10e6], [-2e6, -15e6], [-3e6, -15e6], [-3e6, -20e6], [-62e6, -20e6]]]
                }
            },
            {
                'type': 'Feature',
                'properties': {
                    'deskName': 'Layout_Desk'
                },
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[-25e6, -6e6], [-4e6, -6e6], [-4e6, -10e6], [-25e6, -10e6]]]
                }
            },
            {
                'type': 'Feature',
                'properties': {
                    'deskName': 'Layout_Desk'
                },
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[-25e6, -15e6], [-4e6, -15e6], [-4e6, -19e6], [-25e6, -19e6]]]
                }
            },
            {
                'type': 'Feature',
                'properties': {
                    'deskName': 'Layout_Desk'
                },
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[-61e6, -15e6], [-40e6, -15e6], [-40e6, -19e6], [-61e6, -19e6]]]
                }
            },
            {
                'type': 'Feature',
                'properties': {
                    'deskName': 'HC1',
                    'deskProperties': 'Telephone, Space for 4'
                },
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[-36e6, -15e6], [-33e6, -15e6], [-33e6, -19e6], [-36e6, -19e6]]]
                }
            },
            {
                'type': 'Feature',
                'properties': {
                    'deskName': 'HC48',
                    'status': 'Available',
                    'deskProperties': 'Telephone'
                },
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[-46e6, -17.5e6], [-41e6, -17.5e6], [-41e6, -18.5e6], [-46e6, -18.5e6]]]
                }
            },
            {
                'type': 'Feature',
                'properties': {
                    'deskName': 'HC47',
                    'status': 'Available',
                    'deskProperties': 'Telephone'
                },
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[-53e6, -17.5e6], [-48e6, -17.5e6], [-48e6, -18.5e6], [-53e6, -18.5e6]]]
                }
            },
            {
                'type': 'Feature',
                'properties': {
                    'deskName': 'HC46',
                    'status': 'Available',
                    'deskProperties': 'Telephone'
                },
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[-60e6, -17.5e6], [-55e6, -17.5e6], [-55e6, -18.5e6], [-60e6, -18.5e6]]]
                }
            },
            {
                'type': 'Feature',
                'properties': {
                    'deskName': 'HC45',
                    'status': 'Available',
                    'deskProperties': 'Telephone'
                },
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[-60e6, -15.5e6], [-55e6, -15.5e6], [-55e6, -16.5e6], [-60e6, -16.5e6]]]
                }
            },
            {
                'type': 'Feature',
                'properties': {
                    'deskName': 'HC44',
                    'status': 'Available',
                    'deskProperties': 'Telephone'
                },
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[-53e6, -15.5e6], [-48e6, -15.5e6], [-48e6, -16.5e6], [-53e6, -16.5e6]]]
                }
            },
            {
                'type': 'Feature',
                'properties': {
                    'deskName': 'HC43',
                    'status': 'Available',
                    'deskProperties': 'Telephone'
                },
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[-46e6, -15.5e6], [-41e6, -15.5e6], [-41e6, -16.5e6], [-46e6, -16.5e6]]]
                }
            },
            {
                'type': 'Feature',
                'properties': {
                    'deskName': 'HC42',
                    'status': 'Available',
                    'deskProperties': 'Telephone, USB Keyboard'
                },
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[-24e6, -6.5e6], [-19e6, -6.5e6], [-19e6, -7.5e6], [-24e6, -7.5e6]]]
                }
            },
            {
                'type': 'Feature',
                'properties': {
                    'deskName': 'HC41',
                    'status': 'Booked',
                    'deskProperties': 'Telephone, Monitor, USB Keyboard'
                },
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[-17e6, -6.5e6], [-12e6, -6.5e6], [-12e6, -7.5e6], [-17e6, -7.5e6]]]
                }
            },
            {
                'type': 'Feature',
                'properties': {
                    'deskName': 'HC40',
                    'status': 'Booked',
                    'deskProperties': 'Telephone, Monitor'
                },
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[-10e6, -6.5e6], [-5e6, -6.5e6], [-5e6, -7.5e6], [-10e6, -7.5e6]]]
                }
            },
            {
                'type': 'Feature',
                'properties': {
                    'deskName': 'HC39',
                    'status': 'Available',
                    'deskProperties': 'Telephone, Monitor'
                },
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[-24e6, -8.5e6], [-19e6, -8.5e6], [-19e6, -9.5e6], [-24e6, -9.5e6]]]
                }
            },
            {
                'type': 'Feature',
                'properties': {
                    'deskName': 'HC38',
                    'status': 'Booked',
                    'deskProperties': 'Telephone, Monitor, USB Keyboard'
                },
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[-17e6, -8.5e6], [-12e6, -8.5e6], [-12e6, -9.5e6], [-17e6, -9.5e6]]]
                }
            },
            {
                'type': 'Feature',
                'properties': {
                    'deskName': 'HC37',
                    'status': 'Booked',
                    'deskProperties': 'Telephone'
                },
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[-10e6, -8.5e6], [-5e6, -8.5e6], [-5e6, -9.5e6], [-10e6, -9.5e6]]]
                }
            },
            {
                'type': 'Feature',
                'properties': {
                    'deskName': 'HC36',
                    'status': 'Available',
                    'deskProperties': 'Telephone'
                },
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[-24e6, -15.5e6], [-19e6, -15.5e6], [-19e6, -16.5e6], [-24e6, -16.5e6]]]
                }
            },
            {
                'type': 'Feature',
                'properties': {
                    'deskName': 'HC35',
                    'status': 'Available',
                    'deskProperties': 'Telephone'
                },
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[-17e6, -15.5e6], [-12e6, -15.5e6], [-12e6, -16.5e6], [-17e6, -16.5e6]]]
                }
            },
            {
                'type': 'Feature',
                'properties': {
                    'deskName': 'HC34',
                    'status': 'Available',
                    'deskProperties': 'Telephone'
                },
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[-10e6, -15.5e6], [-5e6, -15.5e6], [-5e6, -16.5e6], [-10e6, -16.5e6]]]
                }
            },
            {
                'type': 'Feature',
                'properties': {
                    'deskName': 'HC33',
                    'status': 'Booked',
                    'deskProperties': 'Telephone'
                },
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[-10e6, -17.5e6], [-5e6, -17.5e6], [-5e6, -18.5e6], [-10e6, -18.5e6]]]
                }
            },
            {
                'type': 'Feature',
                'properties': {
                    'deskName': 'HC32',
                    'status': 'Booked',
                    'deskProperties': 'Telephone'
                },
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[-17e6, -17.5e6], [-12e6, -17.5e6], [-12e6, -18.5e6], [-17e6, -18.5e6]]]
                }
            },
            {
                'type': 'Feature',
                'properties': {
                    'deskName': 'HC31',
                    'status': 'Booked',
                    'deskProperties': 'Telephone'
                },
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[-24e6, -17.5e6], [-19e6, -17.5e6], [-19e6, -18.5e6], [-24e6, -18.5e6]]]
                }
            }
        ]
    };

    var vectorSource = new ol.source.Vector({
        wrapX: false,
        features: (new ol.format.GeoJSON()).readFeatures(geojsonObject)
    });

    vectorSource.addFeature(new ol.Feature(new ol.geom.Circle([-20e6, -3e6], 2.5e6))); //Arch Seat

    vectorSource.addFeature(new ol.Feature(new ol.geom.Circle([-60e6, -12e6], 1.5e6)));	//DiningTable 1
    vectorSource.addFeature(new ol.Feature(new ol.geom.Circle([-60e6, -14.1e6], 0.4e6))); //Seat1
    vectorSource.addFeature(new ol.Feature(new ol.geom.Circle([-57.9e6, -12.2e6], 0.4e6))); //Seat2
    vectorSource.addFeature(new ol.Feature(new ol.geom.Circle([-62.1e6, -12e6], 0.4e6))); //Seat3
    vectorSource.addFeature(new ol.Feature(new ol.geom.Circle([-60e6, -9.9e6], 0.4e6))); //Seat4

    vectorSource.addFeature(new ol.Feature(new ol.geom.Circle([-55e6, -10e6], 1.5e6)));	//DiningTable 2
    vectorSource.addFeature(new ol.Feature(new ol.geom.Circle([-55e6, -12.2e6], 0.4e6))); //Seat1
    vectorSource.addFeature(new ol.Feature(new ol.geom.Circle([-55e6, -7.9e6], 0.4e6))); //Seat2
    vectorSource.addFeature(new ol.Feature(new ol.geom.Circle([-57.1e6, -10e6], 0.4e6))); //Seat3
    vectorSource.addFeature(new ol.Feature(new ol.geom.Circle([-52.9e6, -10e6], 0.4e6))); //Seat4

    vectorSource.addFeature(new ol.Feature(new ol.geom.Circle([-59e6, -7e6], 1.5e6))); //DiningTable 3
    vectorSource.addFeature(new ol.Feature(new ol.geom.Circle([-60e6, -5.2e6], 0.4e6))); //Seat1
    vectorSource.addFeature(new ol.Feature(new ol.geom.Circle([-60.7e6, -8.1e6], 0.4e6))); //Seat2
    vectorSource.addFeature(new ol.Feature(new ol.geom.Circle([-57.2e6, -6e6], 0.4e6))); //Seat3
    vectorSource.addFeature(new ol.Feature(new ol.geom.Circle([-57.9e6, -8.8e6], 0.4e6))); //Seat4

    var vectorLayer = new ol.layer.Vector({
        source: vectorSource,
        style: styleFunction
    });

    var map = new ol.Map({
        layers: [
            vectorLayer
        ],
        target: 'map',
        controls: ol.control.defaults({
            attributionOptions: ({
                collapsible: false
            })
        }),
        view: new ol.View({
            center: [-25e6, -10e6],
            zoom: 2
        })
    });

    map.on("click", function (e) {
        map.forEachFeatureAtPixel(e.pixel, function (feature, layer) {
            var properties = feature.getProperties();
            var coordinate = feature.getGeometry().getCoordinates();
            try {
                if (!properties.deskName.includes("Layout")) {
                    acc[1].classList.toggle("active", true);
                    var panel = acc[1].nextElementSibling;
                    panel.style.display = "block";

                    feature.getProperties().status = "Booked";

                    var IDpos = properties.deskName.indexOf('C') + 1;
                    $scope.deskID = properties.deskName.substring(IDpos);

                    $scope.deskName = "Desk " + properties.deskName;
                    $scope.deskProperties = properties.deskProperties;
                    $scope.$apply();
                }
            } catch (e) {
                console.log("Not a desk");
            }
        })
    });

    map.once("postcompose", function () {
        //start refreshing each 3 seconds
        window.setInterval(function () {
            map.removeLayer(vectorLayer);
            vectorLayer = new ol.layer.Vector({
                source: vectorSource,
                style: styleFunction
            });
            map.addLayer(vectorLayer);
        }, 3000);
    }
    );

    $scope.bookDesk = function () {
        console.log(checkDeskStatus($scope.deskID));
    }

    var checkDeskStatus = function (deskName) {
        var queryURL = "http://localhost:8080/desks/" + deskName;
        var xmlHttp = new XMLHttpRequest();
        xmlHttp.open("GET", queryURL, false); // false for synchronous request
        xmlHttp.send(null);
        var response = xmlHttp.responseText;
        var deskInfo = response.split(",");

        if (deskInfo.length > 4) {
            if (deskInfo[4].indexOf("true") != -1) {
                return "Available";
            } else {
                return "Booked";
            }
        }
        return;
    }

    var getMyBookings = function () {

        var queryURL = "http://localhost:8080/reservations";
        var xmlHttp = new XMLHttpRequest();
        xmlHttp.open("GET", queryURL, false); // false for synchronous request
        xmlHttp.send(null);
        var response = xmlHttp.responseText;
        var deskInfo = response.split("},{");
        var counter = 0;
        $scope.myDesks = Array();
        var employeeCheck = "\"employee\":{\"id\":" + $scope.employeeID;
        for (var s in deskInfo) {
            if (deskInfo[s].indexOf(employeeCheck) != -1) {
                var properties = deskInfo[s].split(",");
                var deskID = properties[4].substring(properties[4].indexOf(":") + 1).replace("\"", "");
                var date = properties[0].substring(properties[0].indexOf(":") + 1).replace("\"", "");
                $scope.myDesks[counter] = {
                    date: date.substring(0, date.length - 1),
                    startTime: properties[1].substring(properties[1].indexOf(":") + 1).replace("\"", ""),
                    endTime: properties[2].substring(properties[2].indexOf(":") + 1).replace("\"", ""),
                    deskID: deskID.substring(0, deskID.length - 1)
                }
                counter++;
            }
        }
        console.log();

    }

    $scope.takeToDesk = function (deskID) {
        for (var x in geojsonObject.features) {

            try {
                var deskName = geojsonObject.features[x].properties.deskName;
                if (deskName === deskID) {
                    var xy = geojsonObject.features[x].geometry.coordinates[0];
                    var y = xy[0][0];
                    var x = xy[0][1];
                    map.setView(new ol.View({
                        center: [x, y],
                        zoom: 4
                    }));
                    console.log("Zoom to " + x + " " + y);
                    break;
                }
            } catch (e) {

            }
        }

        //MapService.pan(selected_options.geom_x, selected_options.geom_y, resoultion)
    }

    $scope.rightClick = function (event) {
        console.log(event);
    };

    getMyBookings();

}
);


angular.module('resourceApp').directive('preventRightClick', [

    function () {
        return {
            restrict: 'A',
            link: function ($scope, $ele) {
                $ele.bind("contextmenu", function (e) {
                    e.preventDefault();
                    if (confirm('Are you sure you want to cancel your booking?')) {
                        // Save it!
                    } else {
                        // Do nothing!
                    }
                });
            }
        };
    }
])